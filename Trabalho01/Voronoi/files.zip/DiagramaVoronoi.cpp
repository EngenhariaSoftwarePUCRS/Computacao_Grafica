//
//  DiagramaVoronoi.cpp
//  OpenGLTest
//
//  Created by Márcio Sarroglia Pinho on 23/08/23.
//  Copyright © 2023 Márcio Sarroglia Pinho. All rights reserved.
//

#include "DiagramaVoronoi.h"

ifstream input;            // ofstream arq;

Voronoi::Voronoi()
{

}
Poligono Voronoi::LeUmPoligono()
{
    Poligono P;
    unsigned int qtdVertices;
    input >> qtdVertices;  // arq << qtdVertices
    for (int i=0; i< qtdVertices; i++)
    {
        double x,y;
        // Le um ponto
        input >> x >> y;
        Ponto(x, y).imprime();
        if(!input)
        {
            cout << "Fim inesperado da linha." << endl;
            break;
        }
        P.insereVertice(Ponto(x,y));
    }
    cout << "Poligono lido com sucesso!" << endl;
    return P;
}

void Voronoi::LePoligonos(const char *nome)
{
    input.open(nome, ios::in); //arq.open(nome, ios::out);
    if (!input)
    {
        cout << "Erro ao abrir " << nome << ". " << endl;
        exit(0);
    }
    string S;

    input >> qtdDePoligonos;
    cout << "qtdDePoligonos:" << qtdDePoligonos << endl;
    Ponto A, B;
    Diagrama[0] = LeUmPoligono();
    Diagrama[0].obtemLimites(Min, Max);// obtem o envelope do poligono
    for (int i=1; i< qtdDePoligonos; i++)
    {
        Diagrama[i] = LeUmPoligono();
        Diagrama[i].obtemLimites(A, B); // obtem o envelope do poligono

        Min = ObtemMinimo (A, Min);
        Max = ObtemMaximo (B, Max);
    }
    cout << "Lista de Poligonos lida com sucesso!" << endl;

}

Poligono Voronoi::getPoligono(int i)
{
    if (i >= qtdDePoligonos)
    {
        cout << "Nro de Poligono Inexistente" << endl;
        return Diagrama[0];
    }
    return Diagrama[i];
}
unsigned int Voronoi::getNPoligonos()
{
    return qtdDePoligonos;
}
void Voronoi::obtemLimites(Ponto &min, Ponto &max)
{
    min = this->Min;
    max = this->Max;
}
// Criar estrutura Vizinhos no Poligono
// Ou alterar o Z do ponto para representar o Vizinho
void Voronoi::obtemVizinhosDasArestas()
{
    for (int i = 0; i < this->getNPoligonos(); i++) {
        Poligono p1 = this->getPoligono(i);
        Poligono p2 = this->getPoligono((i + 1) % this->getNPoligonos());
        for (int j = 0; j < p1.getNVertices(); j++) {
            Ponto p11 = p1.getVertice(i);
            Ponto p12 = p1.getVertice((i + 1) % p1.getNVertices());
            for (int k = 0; k < p2.getNVertices(); k++) {
                Ponto p21 = p2.getVertice(i);
                Ponto p22 = p2.getVertice((i + 1) % p2.getNVertices());

                if (i == 7) {
                        cout << "Poligono: " << i << "\n";
                        p1.pintaPoligono();

                        cout << "P11: ";
                        p11.imprime();
                        cout << "\n";

                        cout << "P12: ";
                        p12.imprime();
                        cout << "\n";


                        cout << "Poligono: " << (i + 1) % this->getNPoligonos() << "\n";

                        cout << "P21: ";
                        p21.imprime();
                        cout << "\n";

                        cout << "P22: ";
                        p22.imprime();
                        cout << "\n";
                }

                if (p11 == p21 && p12 == p22) {
                    cout << "Achemo 1 vizinho entre" << i << " e " << (i + 1) % this->getNPoligonos() << "\n";
                }
            }
        }
    }
}
